tinyMCE.addI18n('sv.paste_dlg',{
text_title:"Anv\u00E4nd ctrl-v p\u00E5 ditt tangentbord f\u00F6r att klistra in i detta f\u00F6nster.",
text_linebreaks:"Spara radbrytningar",
word_title:"Anv\u00E4nd ctrl-v p\u00E5 ditt tangentbord f\u00F6r att klistra in i detta f\u00F6nster."
});