tinyMCE.addI18n('en.insertcode',{
	desc : 'Insert Code'
});
