tinyMCE.addI18n('en.insertcode_dlg',{
	title : 'Insert Code'
});
